UPDATE `tasks` SET sort = id WHERE sort = 0;#
