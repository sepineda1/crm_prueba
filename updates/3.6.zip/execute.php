<?php
function update_invoices_display_id($db, $dbprefix)
{
    $invoices_table = $dbprefix . 'invoices';
    $settings_table = $dbprefix . 'settings';

    $setting_name = "invoice_prefix";
    $invoice_prefix = strtoupper(app_lang("invoice")) . " #";

    $result = $db->query("SELECT * FROM $settings_table WHERE setting_name='$setting_name'");

    if ($result->getNumRows() == 1) {
        //setting alrady exists. Update if the value is blank
        $settting_info = $result->getRow();
        if ($settting_info->setting_value) {
            $invoice_prefix = $settting_info->setting_value;
        } else {
            $db->query("UPDATE $settings_table SET setting_value='$invoice_prefix' WHERE setting_name='$setting_name'");
        }
    } else {
        //add new setting row
        $db->query("INSERT INTO $settings_table (`setting_name`, `setting_value`, `type`, `deleted`) VALUES ('$setting_name', '$invoice_prefix', 'app', 0)");
    }

    $db->query("UPDATE $invoices_table SET display_id=CONCAT('$invoice_prefix', id)");
}

try {
    $db = db_connect('default');
    $dbprefix = $db->getPrefix();

    if (!$dbprefix) {
        $dbprefix = "";
    }

    $upgrade_sql = "upgrade-3.6.sql";
    $sql = file_get_contents($upgrade_sql);

    if ($dbprefix) {
        $sql = str_replace('CREATE TABLE IF NOT EXISTS `', 'CREATE TABLE IF NOT EXISTS `' . $dbprefix, $sql);
        $sql = str_replace('INSERT INTO `', 'INSERT INTO `' . $dbprefix, $sql);
        $sql = str_replace('ALTER TABLE `', 'ALTER TABLE `' . $dbprefix, $sql);
        $sql = str_replace('DELETE FROM `', 'DELETE FROM `' . $dbprefix, $sql);
        $sql = str_replace('UPDATE `', 'UPDATE `' . $dbprefix, $sql);
        $sql = str_replace('DROP TABLE `', 'DROP TABLE `' . $dbprefix, $sql);
    }

    foreach (explode(";#", $sql) as $query) {
        $query = trim($query);
        if ($query) {
            try {
                $db->query($query);
            } catch (\Exception $ex) {
                log_message("error", $ex->getTraceAsString());
            }
        }
    }

    unlink($upgrade_sql);

    update_invoices_display_id($db, $dbprefix);

    $delete_files = array(
        "app/Views/settings/invoices.php",
        "app/Views/tasks/import_tasks_modal_form.php"
    );

    foreach ($delete_files as $file) {
        unlink($file);
    }

    //remove old tasks files. 
} catch (\Exception $exc) {
    log_message("error", $exc->getTraceAsString());
    echo $exc->getTraceAsString();
}
