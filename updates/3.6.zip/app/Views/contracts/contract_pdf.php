<?php 
echo $contract_preview;
