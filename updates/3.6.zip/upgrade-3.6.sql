CREATE TABLE IF NOT EXISTS `folders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `folder_id` varchar(255) NOT NULL,
  `parent_id` int NOT NULL,
  `level` text,
  `created_by` int DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `permissions` text,
  `context` varchar(255) NOT NULL, 
  `context_id` int NOT NULL,
  `starred_by` mediumtext NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;#

CREATE TABLE IF NOT EXISTS `event_tracker` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_type` varchar(255) NOT NULL,
  `context` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `context_id` int NOT NULL,
  `read_count` int NULL,
  `status` enum('new','read') NULL DEFAULT 'new',
  `last_read_time` datetime NULL,
  `created_at` datetime NOT NULL,
  `logs` text NULL,
  `random_id` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `deleted` int NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;#

CREATE TABLE IF NOT EXISTS `proposal_comments` (
 `id` int NOT NULL AUTO_INCREMENT,
 `created_by` int NOT NULL,
 `created_at` datetime NOT NULL,
 `description` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
 `proposal_id` int NOT NULL DEFAULT '0',
 `files` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
 `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;#

UPDATE `settings` SET `setting_value` = CONCAT(setting_value, ',webm') WHERE `setting_name` = 'accepted_file_formats';#

INSERT INTO `settings` (`setting_name`, `setting_value`, `type`, `deleted`) VALUES
('default_permissions_for_non_primary_contact', 'projects', 'app', 0);#

INSERT INTO `notification_settings`(`id`, `event`, `category`, `enable_email`, `enable_web`, `enable_slack`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL,'proposal_commented','proposal','0','0','0',"","","",'77','0');#
INSERT INTO `notification_settings`(`id`, `event`, `category`, `enable_email`, `enable_web`, `enable_slack`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL,'subscription_cancelled','subscription','0','0','0','','','','68','0');#

INSERT INTO `email_templates`(`id`, `template_name`, `email_subject`, `default_message`, `custom_message`, `template_type`, `language`, `deleted`) VALUES (NULL,'subscription_cancelled','Subscription cancelled','<div style="background-color: #eeeeef; padding: 50px 0; "> <div style="max-width:640px; margin:0 auto; "> <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h2>{SUBSCRIPTION_TITLE}</h2></div> <div style="padding: 20px; background-color: rgb(255, 255, 255);">  <p style=""><font color="#606060" face="Arial"><span style="font-size: 15px;">The subscription {SUBSCRIPTION_TITLE} has been cancelled by {CANCELLED_BY}.</span></font><br></p><p style=""><br></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><a style="background-color: #00b393; padding: 10px 15px; color: #ffffff;" href="{SUBSCRIPTION_URL}" target="_blank">Show Subscription</a></span></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><br></span></p><p style="color: rgb(85, 85, 85); font-size: 14px;">{SIGNATURE}</p>  </div> </div></div>','', 'default', '', '0');#
INSERT INTO `email_templates`(`id`, `template_name`, `email_subject`, `default_message`, `custom_message`, `template_type`, `language`, `deleted`) VALUES (NULL,'proposal_commented','Proposal #{PROPOSAL_ID}','<div style="background-color: #eeeeef; padding: 50px 0; "> <div style="max-width:640px; margin:0 auto; "> <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>Proposal #{PROPOSAL_ID} Replies</h1></div><div style="padding: 20px; background-color: rgb(255, 255, 255);"><p style=""><span style="line-height: 18.5714px;">{COMMENT_CONTENT}</span></p><p style=""><span style="line-height: 18.5714px;"><br></span></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><a style="background-color: #00b393; padding: 10px 15px; color: #ffffff;" href="{PROPOSAL_URL}" target="_blank">Show Proposal</a></span></p></div></div></div>',"","default","",0);#

ALTER TABLE `general_files` ADD `folder_id` int NULL DEFAULT '0' AFTER `uploaded_by`, ADD `context` varchar(100) NOT NULL AFTER `folder_id`, ADD `context_id` int NULL DEFAULT '0' AFTER `context`;#

UPDATE `general_files` SET `context` = 'client', `context_id` = client_id WHERE client_id>0;#

ALTER TABLE `invoices` ADD `display_id` text NOT NULL, ADD `number_year` int(11) NULL DEFAULT NULL, ADD `number_sequence` int(11) NULL DEFAULT NULL;#

ALTER TABLE `proposals` ADD `created_by` INT NOT NULL DEFAULT '0' AFTER `accepted_by`, ADD `total_views` int NOT NULL DEFAULT '0' AFTER `created_by`,  ADD `last_preview_seen` datetime DEFAULT NULL AFTER `total_views`;#

ALTER TABLE `notifications` ADD `proposal_comment_id` INT(11) NOT NULL AFTER `expense_id`;#

ALTER TABLE `users`ADD `client_permissions` text NULL AFTER `requested_account_removal`;#

UPDATE `users` SET `client_permissions` = 'all' WHERE user_type='client';#

ALTER TABLE `taxes` CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;#

ALTER TABLE `company` CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;#

ALTER TABLE `notification_settings` CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;#

INSERT INTO `proposal_templates` (`id`, `title`, `template`, `deleted`) VALUES
(NULL, 'Template 3.6', '<table style=\"background-color:#3D3D3D; color:#fff;\" class=\"table\"><tbody><tr><td style=\"text-align: center; \"><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><div style=\"font-size:40px;\"><b>Web Design Proposal</b></div><p></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p></td></tr></tbody></table><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">In response to the growing demands and opportunities within the industry, we propose to develop a comprehensive solution tailored to address key challenges and capitalize on emerging trends. Our proposal aims to deliver tangible value by leveraging our expertise, innovative approaches, and commitment to excellence.</p>\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">{PROPOSAL_ID}</div>\n\n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n\n<div>\nProposal Date: {PROPOSAL_DATE}<br>\nExpiry Date: {PROPOSAL_EXPIRY_DATE}\n</div>\n<table style=\"width: 100%; padding-top: 30px; margin-top: 0;\">\n<tbody>\n<tr>\n<td style=\"width: 50%;padding-left:0; padding-right: 10px;\"><p>Proposal For</p>{PROPOSAL_TO_INFO}</td>\n<td style=\"width: 50%; padding-left: 10px;\"><p>Proposal From</p>{COMPANY_INFO}</td>\n</tr>\n</tbody>\n</table>\n\n<br pagebreak=\"true\">\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">Our Best Offer</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">In consideration of your unique needs and aspirations, we are pleased to present our best offer, crafted with meticulous attention to detail and driven by a commitment to delivering exceptional value.</p><p><br></p>\n\n{PROPOSAL_ITEMS}<p></p><p><br></p><p><br></p><p></p>\n\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">Our Objective</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">Our objective is to align seamlessly with your business goals, leveraging our expertise and resources to drive tangible results and foster long-term success.</p>\n<table style=\"width: 100%;\">\n<tbody><tr>\n<td style=\"width: 50%;vertical-align: top;\">\n<span class=\"timeline-images inline-block\"><img class=\"pasted-image\" src=\"/assets/images/image_preview.png\" alt=\"\" style=\"width:100%;\"></span><span class=\"timeline-images inline-block\"></span>\n</td>\n<td style=\"width: 50%;vertical-align: top;\">\n<span style=\"width: 100%; float: left;\">\n<div style=\"line-height: 26px; padding: 0px 0px 30px;vertical-align:top;\"><span>Through a collaborative partnership, we aim to understand your unique challenges, opportunities, and aspirations, enabling us to tailor our approach to meet your specific needs. By focusing on measurable outcomes, continuous improvement, and proactive communication, we are committed to exceeding your expectations and establishing a foundation for sustained growth and competitiveness in a dynamic business environment.</span><br></div></span>\n</td>\n</tr>\n</tbody></table>\n\n<p></p><p><br></p>\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; \">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">Our Portfolio</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: center;\">Some of our recent work here</p><table class=\"table table-bordered\"><tbody><tr><td><p><span class=\"timeline-images inline-block\"><img class=\"pasted-image\" src=\"/assets/images/image_preview.png\" alt=\"\"></span><span class=\"timeline-images inline-block\"></span><br></p></td><td><p><span class=\"timeline-images inline-block\"></span><span class=\"timeline-images inline-block\"><img class=\"pasted-image\" src=\"/assets/images/image_preview.png\" alt=\"\"></span><br></p></td></tr><tr><td><p><span class=\"timeline-images inline-block\"><img class=\"pasted-image\" src=\"/assets/images/image_preview.png\" alt=\"\"></span><br></p></td><td><p><span class=\"timeline-images inline-block\"><img class=\"pasted-image\" src=\"/assets/images/image_preview.png\" alt=\"\"></span><br></p></td></tr></tbody></table>\n\n<br pagebreak=\"true\">\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">Contact Us</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: center; \">We are looking forward to working with you. Please feel free to contact us.\n</p><p><br></p><p></p><p></p>', 0);#

INSERT INTO `contract_templates` (`id`, `title`, `template`, `deleted`) VALUES
(NULL, 'Template 3.6', '<table style=\"background-color:#3D3D3D; color:#fff;\" class=\"table\"><tbody><tr><td style=\"text-align: center; \"><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><div style=\"\"><span style=\"font-size: 40px;\"><b>{CONTRACT_TITLE}</b></span><br></div><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p></td></tr></tbody></table><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">This contract states the terms and conditions that shall govern the contractual agreement between {COMPANY_NAME} (the Service Provider) and {CONTRACT_TO_COMPANY_NAME} (the Client) who agrees to be bound by the terms of the contract.</p>\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">{CONTRACT_ID}</div>\n\n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n\n<div>\n Contract Date: {CONTRACT_DATE}<br>\n Expiry Date: {CONTRACT_EXPIRY_DATE}\n</div>\n<table style=\"width: 100%; padding-top: 30px; margin-top: 0;\">\n<tbody>\n<tr>\n<td style=\"width: 50%;padding-left:0; padding-right: 10px;\"><p>Client</p>{CONTRACT_TO_INFO}</td>\n<td style=\"width: 50%; padding-left: 10px;\"><p>Service Provider</p>{COMPANY_INFO}</td>\n</tr>\n</tbody>\n</table>\n\n<br pagebreak=\"true\">\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">Service Details</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">The specific scope, timeline, and any additional requirements related to the services shall be detailed in a separate document or statement of work, which shall form an integral part of this contract.</p><p><br></p>\n\n{CONTRACT_ITEMS}<p></p><p><br></p><p><br></p><p></p>\n\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">1. Service Policy</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">The Service Policy outlines the terms and conditions governing the provision of services by Service Provider to the Client. It encompasses guidelines regarding service delivery, quality standards, support mechanisms, and dispute resolution procedures. The Service Provider is committed to upholding the highest level of professionalism, responsiveness, and customer satisfaction in delivering the agreed upon services.</p><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">Any deviations from the Service Policy shall be communicated promptly and resolved in a timely manner to ensure seamless collaboration and adherence to the mutual objectives outlined in the contract.</p><p style=\"text-align: justify; \"><br></p>\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">2. Delivery</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">The Service Provider will commence delivery of services upon receipt of a signed contract and any necessary initial payments as specified. Delivery timelines and milestones will be outlined in the project schedule or statement of work provided to the Client. The Service Provider will make reasonable efforts to meet agreed-upon deadlines and milestones, keeping the Client informed of any delays or changes to the delivery schedule. Delivery methods may vary depending on the nature of the services and may include in-person meetings, electronic communication, or physical shipment of goods.</p><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">Upon completion of the services, the Client will be provided with deliverables as outlined in the project scope or statement of work, with any necessary documentation or training materials included as specified.</p><p style=\"text-align: justify; \"><br></p>\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">3. Intellectual property rights</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">All intellectual property rights, including but not limited to copyrights, patents, trademarks, and trade secrets, associated with the services provided under this contract shall remain the exclusive property of the originating party unless otherwise agreed upon in writing. The Service Provider retains ownership of any proprietary methodologies, technologies, or materials utilized in delivering the services, and the Client agrees not to reproduce, distribute, or disclose such intellectual property without prior written consent.</p><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">Any intellectual property created or developed during the course of providing the services shall be jointly owned by both parties unless otherwise specified in a separate agreement. Any use or exploitation of intellectual property rights beyond the scope of this contract requires the express written consent of the owning party.</p><p style=\"text-align: justify; \"><br></p>\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">4. Confidentiality</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">Both parties agree to maintain strict confidentiality regarding any proprietary or sensitive information disclosed during the course of this contract. This includes but is not limited to trade secrets, business strategies, financial information, and client data. The Service Provider shall take all necessary precautions to prevent unauthorized access or disclosure of confidential information and shall only share such information with authorized personnel directly involved in fulfilling the obligations of this contract.</p><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">The Client agrees not to disclose any confidential information obtained from the Service Provider to any third parties without prior written consent. This confidentiality obligation shall survive the termination of this contract and continue indefinitely thereafter.</p><p style=\"text-align: justify; \"><br></p>\n<br pagebreak=\"true\">\n\n<table style=\"margin-top: 0; margin-bottom: 10px;\">\n    <tbody>\n        <tr>\n            <td style=\"padding: 0;\">\n                <div style=\"margin-top: 20px\">\n                    <div style=\"text-align: center\">\n                        <div style=\"font-size: 30px\">5. Support</div>\n                        \n<table style=\"margin-top: 10px;\"><tbody><tr><td></td><td></td><td></td><td><div style=\"border-bottom: 5px solid #ff9800;\"></div></td><td></td><td></td><td></td></tr></tbody></table>\n                    </div>\n                </div>\n            </td>\n        </tr>\n    </tbody>\n</table>\n<p style=\"text-align: justify; \">The Service Provider agrees to provide reasonable support and assistance to the Client during the term of this contract. Support may include but is not limited to troubleshooting, technical assistance, and guidance related to the services provided. The Service Provider will make commercially reasonable efforts to respond promptly to inquiries and requests for support from the Client, within the parameters specified in the service level agreement (SLA) or support agreement. Support will be provided during normal business hours unless otherwise agreed upon. Any additional support beyond the scope outlined in this contract may be subject to additional fees or terms as mutually agreed upon by both parties.<br></p><p style=\"text-align: justify; \"><br></p><p style=\"text-align: justify; \">{CONTRACT_NOTE}</p>\n\n', 0);#

ALTER TABLE `activity_logs` ADD INDEX( `log_for`, `log_for_id`);#

ALTER TABLE `activity_logs` ADD INDEX( `log_for2`, `log_for_id2`);#

ALTER TABLE `activity_logs` ADD INDEX( `log_type`, `log_type_id`);#

ALTER TABLE `activity_logs` ADD INDEX( `created_by`);#

ALTER TABLE `clients` ADD INDEX( `owner_id`);#

ALTER TABLE `clients` ADD INDEX( `created_by`);#

ALTER TABLE `clients` ADD INDEX( `lead_source_id`);#

ALTER TABLE `clients` ADD INDEX( `is_lead`);#

ALTER TABLE `dashboards` ADD INDEX( `user_id`);#

ALTER TABLE `custom_fields` ADD INDEX( `field_type`);#

ALTER TABLE `custom_widgets` ADD INDEX( `user_id`);#

ALTER TABLE `events` ADD INDEX(`project_id`);#

ALTER TABLE `events` ADD INDEX(`task_id`);#

ALTER TABLE `events` ADD INDEX(`recurring`);#

ALTER TABLE `events` ADD INDEX(`start_date`);#

ALTER TABLE `events` ADD INDEX(`end_date`);#

ALTER TABLE `expenses` ADD INDEX(`category_id`);#

ALTER TABLE `invoices` ADD INDEX(`client_id`);#

ALTER TABLE `invoices` ADD INDEX(`project_id`);#

ALTER TABLE `labels` ADD INDEX(`context`);#

ALTER TABLE `projects` ADD INDEX(`client_id`);#

ALTER TABLE `projects` ADD INDEX(`status_id`);#

ALTER TABLE `project_members` ADD INDEX(`user_id`);#

ALTER TABLE `project_members` ADD INDEX(`project_id`);#

ALTER TABLE `tasks` ADD INDEX(`status_id`);#

ALTER TABLE `tasks` ADD INDEX(`priority_id`);#

ALTER TABLE `tasks` ADD INDEX(`sort`);#

ALTER TABLE `tasks` ADD INDEX(`project_id`);#

ALTER TABLE `tasks` ADD INDEX(`milestone_id`);#

ALTER TABLE `tasks` ADD INDEX(`assigned_to`);#

ALTER TABLE `tasks` ADD INDEX(`ticket_id`);#

ALTER TABLE `tasks` ADD INDEX(`client_id`);#

ALTER TABLE `tasks` ADD INDEX(`invoice_id`);#

ALTER TABLE `tasks` ADD INDEX(`estimate_id`);#

ALTER TABLE `tasks` ADD INDEX(`order_id`);#

ALTER TABLE `tasks` ADD INDEX(`contract_id`);#

ALTER TABLE `tasks` ADD INDEX(`proposal_id`);#

ALTER TABLE `tasks` ADD INDEX(`subscription_id`);#

ALTER TABLE `tasks` ADD INDEX(`expense_id`);#

ALTER TABLE `tasks` ADD INDEX(`lead_id`);#

ALTER TABLE `tickets` ADD INDEX(`client_id`);#

ALTER TABLE `tickets` ADD INDEX(`ticket_type_id`);#

ALTER TABLE `tickets` ADD INDEX(`assigned_to`);#

ALTER TABLE `to_do` ADD INDEX(`created_by`);#









