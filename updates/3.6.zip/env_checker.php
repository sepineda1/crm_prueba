<?php
$response = "acknowledgement_required";

$message = "Note: After this update, team members will not be able to access the project comments and project files by default. Please remember to set the permissions from the Settings>Access Permission>Roles>Permissions page, to allow the access.";

return array("response_type"=>$response, "message"=>$message);