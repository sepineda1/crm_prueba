
ALTER TABLE `contracts` CHANGE `content` `content` mediumtext COLLATE utf8_unicode_ci NOT NULL;#

ALTER TABLE `proposals` CHANGE `content` `content` mediumtext COLLATE utf8_unicode_ci NOT NULL;#

ALTER TABLE `custom_widgets` CHANGE `content` `content` mediumtext COLLATE utf8_unicode_ci;#