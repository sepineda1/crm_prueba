<div class="app-modal">
    <div class="app-modal-content">
        <?php echo view("includes/file_preview"); ?>
    </div>
</div>