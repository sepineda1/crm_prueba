<?php

echo company_widget($order_info->company_id, "order");
